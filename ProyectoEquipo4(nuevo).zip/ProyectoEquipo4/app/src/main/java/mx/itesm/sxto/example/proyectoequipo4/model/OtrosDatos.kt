package mx.itesm.sxto.example.proyectoequipo4.model

import com.google.gson.annotations.SerializedName

data class OtrosDatos(
    @SerializedName("country")
    val nombre: String,
    @SerializedName("cases")
    val casos: Int,
    @SerializedName("countryInfo")
    val info: Map<String, String> = mapOf(),
    val idImagen: Int = 0,      // Inicia en 0 si no recibe nada
    val urlImagen: String = ""
)
