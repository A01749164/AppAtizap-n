package mx.itesm.sxto.example.proyectoequipo4.adaptadores

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import mx.itesm.sxto.example.proyectoequipo4.R
import mx.itesm.sxto.example.proyectoequipo4.model.ProtegidosDatos

class AdaptadorProtegidos(private val contexto: Context, var arrProtegidos: Array<ProtegidosDatos>) :
    RecyclerView.Adapter<AdaptadorProtegidos.RenglonProtegidos>()
{
    // Se llama cada vez que se va a poblar un renglon
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RenglonProtegidos {
        val vista = LayoutInflater.from(contexto).inflate(R.layout.renglon_protegidos, parent, false)
        return RenglonProtegidos(vista)
    }

    // Para poblar un renglón (poner los datos en el renglón 'position')
    override fun onBindViewHolder(holder: RenglonProtegidos, position: Int) {
        val protegidos = arrProtegidos[position]
        holder.set(protegidos)
    }


    // El número de renglones que tendra el recyclerview
    override fun getItemCount(): Int {
        return arrProtegidos.size
    }

    class RenglonProtegidos(var renglonprotegidos: View) : RecyclerView.ViewHolder(renglonprotegidos) {
        fun set(protegido: ProtegidosDatos) {
            renglonprotegidos.findViewById<TextView>(R.id.PaisS).text = protegido.nombre
            renglonprotegidos.findViewById<TextView>(R.id.AñoS).text = protegido.categoria
            renglonprotegidos.findViewById<TextView>(R.id.PorcentajeS).text = "${protegido.superficie}"
        }
    }
}
