package mx.itesm.sxto.example.proyectoequipo4.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import mx.itesm.sxto.example.proyectoequipo4.model.InfoProtegidos
import mx.itesm.sxto.example.proyectoequipo4.apis.ServicioProtegidosAPI
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class IncendiosVM : ViewModel() {
    // Modelo
    private val retrofit by lazy { // El objeto retrofit para instanciar
        //el objeto que se conecta a la red y accede a los servicios definidos
        Retrofit.Builder()
            .baseUrl("https://analisis.datosabiertos.jcyl.es/api/records/1.0/search/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    // Instancia que crea el objeto que realiza la descarga
    private val servicioIncendiosAPI by lazy {
        retrofit.create(ServicioProtegidosAPI::class.java)
    }

    // Livedata (Observables)
    val listaincendios = MutableLiveData<InfoProtegidos>()

    fun descargarDatosIncendios() {
        println("descargarDatosIncendios")
        val call = servicioIncendiosAPI.descargarDatosProtegidos() // Crea un objeto para descargar
        call.enqueue(object : Callback<InfoProtegidos> { // DESCARGA ASÍNCRONA
            override fun onResponse(call: Call<InfoProtegidos>, response: Response<InfoProtegidos>) {
                if (response.isSuccessful) {
                    println("Lista incendios: ${response.body()}")
                    // Avisar a la vista (adaptador) que hay datos nuevos
                    listaincendios.value = response.body()
                } else {
                    println("Error en los datos: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<InfoProtegidos>, t: Throwable) {
                println("Error en la descarga: ${t.localizedMessage}")
            }
        })
    }
}