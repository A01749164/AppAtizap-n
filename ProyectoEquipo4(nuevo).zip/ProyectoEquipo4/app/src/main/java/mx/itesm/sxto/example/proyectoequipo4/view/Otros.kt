package mx.itesm.sxto.example.proyectoequipo4.view

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import mx.itesm.sxto.example.proyectoequipo4.adaptadores.AdaptadorOtros
import mx.itesm.sxto.example.proyectoequipo4.databinding.ActivityOtrosBinding
import mx.itesm.sxto.example.proyectoequipo4.model.OtrosDatos
import mx.itesm.sxto.example.proyectoequipo4.viewmodel.OtrosVM

class Otros : AppCompatActivity()
{
    // binding
    private lateinit var binding: ActivityOtrosBinding
    // ViewModel
    private val viewModel: OtrosVM by viewModels()
    // Fuente de datos del RecyclerView
    var adaptadorOtros : AdaptadorOtros? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOtrosBinding.inflate(layoutInflater)
        setContentView(binding.root)
        println("Estoy en otros")

        configurarRV()
        configurarObservables()
        viewModel.descargarDatosOtros()
        registrarEventos()
    }

    private fun configurarObservables() {
        viewModel.listaotros.observe(this) { lista ->
            val listaOtros = lista.toTypedArray()
            adaptadorOtros?.arrOtros = listaOtros
            adaptadorOtros?.notifyDataSetChanged() // Recargue todo

        }
    }

    override fun onStart() {
        super.onStart()
        viewModel.descargarDatosOtros()
    }

    private fun configurarRV() {
        val arrOtros = arrayOf(OtrosDatos("México", 5300),
            OtrosDatos("Argentina", 25336))
        val layout = LinearLayoutManager(this)
        layout.orientation = LinearLayoutManager.VERTICAL
        binding.RVOtros.layoutManager = layout
        adaptadorOtros = AdaptadorOtros(this, arrOtros)
        binding.RVOtros.adapter = adaptadorOtros

        val divisor = DividerItemDecoration(this, layout.orientation)
        binding.RVOtros.addItemDecoration(divisor)
    }

    private fun registrarEventos() {
        // Boton que nos manda a la vista principal
        binding.btnRegresarOtros.setOnClickListener {
            println("Voy a menú")
            val intMenu = Intent(this, MainActivity::class.java)
            startActivity(intMenu)
        }
    }
}