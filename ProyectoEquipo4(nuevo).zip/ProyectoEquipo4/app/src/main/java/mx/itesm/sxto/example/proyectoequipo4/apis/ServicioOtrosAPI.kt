package mx.itesm.sxto.example.proyectoequipo4.apis

import mx.itesm.sxto.example.proyectoequipo4.model.OtrosDatos
import retrofit2.Call
import retrofit2.http.GET

interface ServicioOtrosAPI {
    @GET("v3/covid-19/countries")
    fun descargarDatosOtros(): Call<List<OtrosDatos>>
}