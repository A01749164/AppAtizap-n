package mx.itesm.sxto.example.proyectoequipo4.view

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import mx.itesm.sxto.example.proyectoequipo4.adaptadores.AdaptadorProtegidos
import mx.itesm.sxto.example.proyectoequipo4.databinding.ActivityIncendiosBinding
import mx.itesm.sxto.example.proyectoequipo4.model.ProtegidosDatos
import mx.itesm.sxto.example.proyectoequipo4.viewmodel.IncendiosVM

class Incendios : AppCompatActivity()
{
    // binding
    private lateinit var binding: ActivityIncendiosBinding
    // ViewModel
    private val viewModel: IncendiosVM by viewModels()
    // Fuente de datos del RecyclerView
    var adaptadorProtegidos : AdaptadorProtegidos? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityIncendiosBinding.inflate(layoutInflater)
        setContentView(binding.root)
        println("Estoy en incendios")

        configurarRV()
        configurarObservables()
        viewModel.descargarDatosIncendios()
        registrarEventos()
    }

    private fun configurarObservables() {
        viewModel.listaincendios.observe(this) { lista ->
            val arrProtegidos = lista.data.toTypedArray()
            adaptadorProtegidos?.arrProtegidos = arrProtegidos
            adaptadorProtegidos?.notifyDataSetChanged() // Recargue todo

        }
    }

    override fun onStart() {
        super.onStart()
        viewModel.descargarDatosIncendios()
    }

    private fun configurarRV() {
        val arrProtegidos = arrayOf(ProtegidosDatos("Null", "null", "null", 0.0))
        val layout = LinearLayoutManager(this)
        layout.orientation = LinearLayoutManager.VERTICAL
        binding.RVIncendios.layoutManager = layout
        adaptadorProtegidos = AdaptadorProtegidos(this, arrProtegidos)
        binding.RVIncendios.adapter = adaptadorProtegidos

        val divisor = DividerItemDecoration(this, layout.orientation)
        binding.RVIncendios.addItemDecoration(divisor)
    }

    private fun registrarEventos() {
        // Boton que nos manda a la vista principal
        binding.btnRegresarIncendios.setOnClickListener {
            println("Voy a menú")
            val intMenu = Intent(this, MainActivity::class.java)
            startActivity(intMenu)
        }
    }
}