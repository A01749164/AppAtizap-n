package mx.itesm.sxto.example.proyectoequipo4.model

import com.google.gson.annotations.SerializedName

data class SuicidioDatos(
    @SerializedName("name")
    val pais: String,
    @SerializedName("year")
    val año: String,
    @SerializedName("rate")
    val porcentaje: Double,
    @SerializedName("description")
    val descripcion: String
)
