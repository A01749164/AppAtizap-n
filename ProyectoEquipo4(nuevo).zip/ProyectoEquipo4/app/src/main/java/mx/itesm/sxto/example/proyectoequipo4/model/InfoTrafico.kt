package mx.itesm.sxto.example.proyectoequipo4.model

import com.google.gson.annotations.SerializedName

data class InfoTrafico(
    @SerializedName("data")
    val data: List<TraficoDatos>
)
