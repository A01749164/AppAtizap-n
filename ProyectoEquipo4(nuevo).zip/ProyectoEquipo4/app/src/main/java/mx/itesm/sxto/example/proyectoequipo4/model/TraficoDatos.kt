package mx.itesm.sxto.example.proyectoequipo4.model

import com.google.gson.annotations.SerializedName

data class TraficoDatos(
    @SerializedName("title")
    val titulo: String ,
    @SerializedName("date")
    val fecha: String,
    @SerializedName("gtype")
    val tipo: String,
    @SerializedName("continent")
    val continente: String,
    @SerializedName("country")
    val pais: String
)
