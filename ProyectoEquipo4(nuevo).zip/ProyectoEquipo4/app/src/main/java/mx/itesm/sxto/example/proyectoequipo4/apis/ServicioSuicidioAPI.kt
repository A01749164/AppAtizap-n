package mx.itesm.sxto.example.proyectoequipo4.apis

import mx.itesm.sxto.example.proyectoequipo4.model.SuicidioDatos
import retrofit2.Call
import retrofit2.http.GET

interface ServicioSuicidioAPI {
    @GET("4trd-afea.json")
    fun descargarDatosChoques(): Call<List<SuicidioDatos>>
}