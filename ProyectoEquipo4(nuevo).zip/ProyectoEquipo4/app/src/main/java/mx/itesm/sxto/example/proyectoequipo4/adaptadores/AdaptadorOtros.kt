package mx.itesm.sxto.example.proyectoequipo4.adaptadores

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import mx.itesm.sxto.example.proyectoequipo4.R
import mx.itesm.sxto.example.proyectoequipo4.model.OtrosDatos

class AdaptadorOtros(private val contexto: Context, var arrOtros: Array<OtrosDatos>) :
    RecyclerView.Adapter<AdaptadorOtros.RenglonOtros>()
{
    // Se llama cada vez que se va a poblar un renglon
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RenglonOtros {
        val vista = LayoutInflater.from(contexto).inflate(R.layout.renglon_otros, parent, false)
        return RenglonOtros(vista)
    }

    // Para poblar un renglón (poner los datos en el renglón 'position')
    override fun onBindViewHolder(holder: RenglonOtros, position: Int) {
        val otros = arrOtros[position]
        holder.set(otros)
    }


    // El número de renglones que tendra el recyclerview
    override fun getItemCount(): Int {
        return arrOtros.size
    }

    class RenglonOtros(var renglonOtros: View) : RecyclerView.ViewHolder(renglonOtros) {
        fun set(otros: OtrosDatos) {
            renglonOtros.findViewById<TextView>(R.id.PaisO).text = otros.nombre
            renglonOtros.findViewById<TextView>(R.id.CasosO).text = "${otros.casos}"
            renglonOtros.findViewById<ImageView>(R.id.imgBandera).setImageResource(R.drawable.bandera)
            println(otros.info["flag"])  // Revisar si imprime el url de las banderas
            val url = otros.info["flag"]
            val imgBandera = renglonOtros.findViewById<ImageView>(R.id.imgBandera)
            Glide.with(renglonOtros.context).load(url).into(imgBandera)
        }
    }
}