package mx.itesm.sxto.example.proyectoequipo4.view

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import mx.itesm.sxto.example.proyectoequipo4.databinding.ActivityMainBinding
import mx.itesm.sxto.example.proyectoequipo4.viewmodel.InundacionesVM

class MainActivity : AppCompatActivity()
{
    // binding
    private lateinit var binding: ActivityMainBinding

    // ViewModel
    private val viewModel: InundacionesVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        registrarEventos()
    }

    private fun registrarEventos() {
        // Boton que nos manda a la vista inundaciones
        binding.btnInundaciones.setOnClickListener{
            println("Voy a inundaciones")
            val intInundaciones = Intent(this, Inundaciones::class.java)
            startActivity(intInundaciones)
        }
        // Boton que nos manda a la vista incendios
        binding.btnIncendios.setOnClickListener{
            println("Voy a incendios")
            val intIncendios = Intent(this, Incendios::class.java)
            startActivity(intIncendios)
        }
        // Boton que nos manda a la vista accidentes
        binding.btnAccidentes.setOnClickListener{
            println("Voy a choques")
            val intChoques = Intent(this, Suicidio::class.java)
            startActivity(intChoques)
        }
        // Boton que nos manda a la vista trafico
        binding.btnTrafico.setOnClickListener{
            println("Voy a trafico")
            val intTrafico = Intent(this, Trafico::class.java)
            startActivity(intTrafico)
        }
        // Boton que nos manda a la vista sismos
        binding.btnSismos.setOnClickListener{
            println("Voy a sismos")
            val intSismos = Intent(this, Sismos::class.java)
            startActivity(intSismos)
        }
        // Boton que nos manda a la vista otros
        binding.btnOtros.setOnClickListener{
            println("Voy a otros")
            val intOtros = Intent(this, Otros::class.java)
            startActivity(intOtros)
        }
        // Boton que nos manda a la vista sos
        binding.btnSOS.setOnClickListener{
            println("Voy a sos")
            val intSos = Intent(this, SOS::class.java)
            startActivity(intSos)
        }
    }

}