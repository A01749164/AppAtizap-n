package mx.itesm.sxto.example.proyectoequipo4.model

import com.google.gson.annotations.SerializedName

data class ProtegidosDatos(
    @SerializedName("espacio_prot_figura")
    val nombre: String ,
    @SerializedName("spacio_prot_categoria")
    val categoria: String,
    @SerializedName("espacio_prot_fecha_declaracion")
    val declaracion: String,
    @SerializedName("espacio_prot_superficie_ha")
    val superficie: Double

)
