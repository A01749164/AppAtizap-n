package mx.itesm.sxto.example.proyectoequipo4.model

import com.google.gson.annotations.SerializedName

data class ReforestacionDatos (
    @SerializedName("repobl_forestales_año")
    val año: Int,
    @SerializedName("repobl_forestales_grupo_veget")
    val tipoarbol: String,
    @SerializedName("repobl_forestales_sup_ha")
    val superficie: Double
        )
