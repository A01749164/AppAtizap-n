package mx.itesm.sxto.example.proyectoequipo4.adaptadores

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import mx.itesm.sxto.example.proyectoequipo4.R
import mx.itesm.sxto.example.proyectoequipo4.model.ReforestacionDatos

class AdaptadorReforestacion(private val contexto: Context, var arrReforestacion: Array<ReforestacionDatos>) :
    RecyclerView.Adapter<AdaptadorReforestacion.RenglonReforestacion>()
{
    // Se llama cada vez que se va a poblar un renglon
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RenglonReforestacion {
        val vista = LayoutInflater.from(contexto).inflate(R.layout.renglon_reforestacion, parent, false)
        return RenglonReforestacion(vista)
    }

    // Para poblar un renglón (poner los datos en el renglón 'position')
    override fun onBindViewHolder(holder: RenglonReforestacion, position: Int) {
        val reforestacion = arrReforestacion[position]
        holder.set(reforestacion)
    }


    // El número de renglones que tendra el recyclerview
    override fun getItemCount(): Int {
        return arrReforestacion.size
    }

    class RenglonReforestacion(var renglonReforestacion: View) : RecyclerView.ViewHolder(renglonReforestacion) {
        fun set(reforestacion: ReforestacionDatos) {
            renglonReforestacion.findViewById<TextView>(R.id.FechaS).text = "${reforestacion.año}"
            renglonReforestacion.findViewById<TextView>(R.id.HoraS).text = reforestacion.tipoarbol
            renglonReforestacion.findViewById<TextView>(R.id.LatitudS).text = "${reforestacion.superficie}"
        }
    }
}