package mx.itesm.sxto.example.proyectoequipo4.model

import com.google.gson.annotations.SerializedName

data class InfoReforestacion(
    @SerializedName("data")
       val features: List<ReforestacionDatos>
)
    