package mx.itesm.sxto.example.proyectoequipo4.apis

import mx.itesm.sxto.example.proyectoequipo4.model.InfoReforestacion
import retrofit2.Call
import retrofit2.http.GET

interface ServicioSismosAPI {
    @GET("https://datos.comunidad.madrid/catalogo/dataset/f12c5e2f-3aa8-4b59-a0ed-e9edf04e3f07/resource/c8196822-093c-4f8d-8c50-8497df7d2a43/download/repoblaciones_forestales.json")
    fun descargarDatosReforestacion(): Call<InfoReforestacion>
}