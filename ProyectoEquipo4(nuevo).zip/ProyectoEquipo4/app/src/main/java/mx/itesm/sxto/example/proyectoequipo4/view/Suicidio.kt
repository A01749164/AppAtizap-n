package mx.itesm.sxto.example.proyectoequipo4.view

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import mx.itesm.sxto.example.proyectoequipo4.adaptadores.AdaptadorSuicidio
import mx.itesm.sxto.example.proyectoequipo4.databinding.ActivitySuicidiosBinding
import mx.itesm.sxto.example.proyectoequipo4.model.SuicidioDatos
import mx.itesm.sxto.example.proyectoequipo4.viewmodel.SuicidioVM

class Suicidio : AppCompatActivity()
{
    // binding
    private lateinit var binding: ActivitySuicidiosBinding
    // ViewModel
    private val viewModel: SuicidioVM by viewModels()
    // Fuente de datos del RecyclerView
    var adaptadorSuicidios : AdaptadorSuicidio? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySuicidiosBinding.inflate(layoutInflater)
        setContentView(binding.root)
        println("Estoy en Porcentaje de Suicidio Relacionado por rango de edad")

        configurarRV()
        configurarObservables()
        viewModel.descargarDatosSuicidio()
        registrarEventos()
    }

    private fun configurarObservables() {
        viewModel.listasuicidios.observe(this) { lista ->
            val listaSuicidio = lista.toTypedArray()
            adaptadorSuicidios?.arrSuicidios = listaSuicidio
            adaptadorSuicidios?.notifyDataSetChanged() // Recargue todo

        }
    }

    override fun onStart() {
        super.onStart()
        viewModel.descargarDatosSuicidio()
    }

    private fun configurarRV() {
        val arrChoques = arrayOf(SuicidioDatos("USA", "2010", 12.54, "Porcentaje"))
        val layout = LinearLayoutManager(this)
        layout.orientation = LinearLayoutManager.VERTICAL
        binding.RVChoques.layoutManager = layout
        adaptadorSuicidios = AdaptadorSuicidio(this, arrChoques)
        binding.RVChoques.adapter = adaptadorSuicidios

        val divisor = DividerItemDecoration(this, layout.orientation)
        binding.RVChoques.addItemDecoration(divisor)
    }

    private fun registrarEventos() {
        // Boton que nos manda a la vista principal
        binding.btnRegresarSuicidios.setOnClickListener {
            println("Voy a menú")
            val intMenu = Intent(this, MainActivity::class.java)
            startActivity(intMenu)
        }
    }
}