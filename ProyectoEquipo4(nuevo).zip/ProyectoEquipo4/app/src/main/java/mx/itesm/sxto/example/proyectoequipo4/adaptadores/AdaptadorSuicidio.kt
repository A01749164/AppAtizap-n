package mx.itesm.sxto.example.proyectoequipo4.adaptadores

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import mx.itesm.sxto.example.proyectoequipo4.R
import mx.itesm.sxto.example.proyectoequipo4.model.SuicidioDatos

class AdaptadorSuicidio(private val contexto: Context, var arrSuicidios: Array<SuicidioDatos>) :
    RecyclerView.Adapter<AdaptadorSuicidio.RenglonSuicidios>() {
    // Se llama cada vez que se va a poblar un renglon
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RenglonSuicidios {
        val vista = LayoutInflater.from(contexto).inflate(R.layout.renglon_suicidios, parent, false)
        return RenglonSuicidios(vista)
    }

    // Para poblar un renglón (poner los datos en el renglón 'position')
    override fun onBindViewHolder(holder: RenglonSuicidios, position: Int) {
        val suicidios = arrSuicidios[position]
        holder.set(suicidios)
    }


    // El número de renglones que tendra el recyclerview
    override fun getItemCount(): Int {
        return arrSuicidios.size
    }

    class RenglonSuicidios(var renglonSuicidios: View) : RecyclerView.ViewHolder(renglonSuicidios) {
        fun set(suicidio: SuicidioDatos) {
            renglonSuicidios.findViewById<TextView>(R.id.PaisS).text = suicidio.pais
            renglonSuicidios.findViewById<TextView>(R.id.AñoS).text = suicidio.año
            renglonSuicidios.findViewById<TextView>(R.id.PorcentajeS).text = "${suicidio.porcentaje}"
            renglonSuicidios.findViewById<TextView>(R.id.DescripcionS).text = suicidio.descripcion
        }
    }
}