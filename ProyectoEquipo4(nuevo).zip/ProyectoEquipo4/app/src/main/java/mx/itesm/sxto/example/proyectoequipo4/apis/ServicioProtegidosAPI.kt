package mx.itesm.sxto.example.proyectoequipo4.apis

import mx.itesm.sxto.example.proyectoequipo4.model.InfoProtegidos
import retrofit2.Call
import retrofit2.http.GET

interface ServicioProtegidosAPI {
    @GET("https://datos.comunidad.madrid/catalogo/dataset/762d9899-8e66-4de3-87ed-f289b9c3e1ab/resource/3510ee53-4385-4ffb-9b3f-728e5c9432a1/download/espacios_protegidos.json")
    fun descargarDatosProtegidos(): Call<InfoProtegidos>
}