package mx.itesm.sxto.example.proyectoequipo4.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import mx.itesm.sxto.example.proyectoequipo4.apis.ServicioSuicidioAPI
import mx.itesm.sxto.example.proyectoequipo4.model.SuicidioDatos
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class SuicidioVM : ViewModel()
{
    // Modelo
    private val retrofit by lazy { // El objeto retrofit para instanciar
        //el objeto que se conecta a la red y accede a los servicios definidos
        Retrofit.Builder()
            .baseUrl("https://healthstat.dph.sbcounty.gov/resource/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    // Instancia que crea el objeto que realiza la descarga
    private val servicioChoqueAPI by lazy {
        retrofit.create(ServicioSuicidioAPI::class.java)
    }

    // Livedata (Observables)
    val listasuicidios = MutableLiveData<List<SuicidioDatos>>()

    fun descargarDatosSuicidio() {
        println("descargarDatosSuicidio")
        val call = servicioChoqueAPI.descargarDatosChoques() // Crea un objeto para descargar
        call.enqueue(object : Callback<List<SuicidioDatos>> { // DESCARGA ASÍNCRONA
            override fun onResponse(call: Call<List<SuicidioDatos>>, response: Response<List<SuicidioDatos>>) {
                if (response.isSuccessful) {
                    println("Lista Choques: ${response.body()}")
                    // Avisar a la vista (adaptador) que hay datos nuevos
                    listasuicidios.value = response.body()
                } else {
                    println("Error en los datos: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<List<SuicidioDatos>>, t: Throwable) {
                println("Error en la descarga: ${t.localizedMessage}")
            }
        })
    }
}