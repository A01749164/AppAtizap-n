package mx.itesm.sxto.example.proyectoequipo4.apis

import mx.itesm.sxto.example.proyectoequipo4.model.InfoTrafico
import retrofit2.Call
import retrofit2.http.GET

interface ServicioTraficoAPI {
    @GET("https://hub.worldpop.org/rest/data/pop/wpgp?iso3=AUS")
    fun descargarDatosTrafico(): Call<InfoTrafico>
}